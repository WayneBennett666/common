# My Custom Functions

This is a small custom package of functions that I use all the time.