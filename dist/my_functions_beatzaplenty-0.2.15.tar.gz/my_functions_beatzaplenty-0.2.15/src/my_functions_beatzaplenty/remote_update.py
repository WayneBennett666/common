import sys
import my_functions_beatzaplenty.general_purpose as general_purpose
containers = sys.argv[1:]
general_purpose.run_updates(containers)
