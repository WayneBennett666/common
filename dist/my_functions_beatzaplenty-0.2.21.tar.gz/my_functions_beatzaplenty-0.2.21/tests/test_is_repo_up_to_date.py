import os
import subprocess
import pytest
#     ###################### LOAD TESTING MODULE  ###########################
from importlib.machinery import SourceFileLoader
from os import getenv
test = SourceFileLoader("create_config_file", f"{getenv('HOME')}/common/src/my_functions_beatzaplenty/general_purpose.py").load_module()
  #############################################################################
@pytest.fixture
def temp_git_repo(tmp_path):
    # Create a temporary Git repository
    repo_path = tmp_path / "test_repo"
    os.makedirs(repo_path)
    subprocess.run(['git', 'init'], cwd=repo_path, check=True)
    return repo_path

def test_is_repo_up_to_date(temp_git_repo, capsys):
    # Check if the initial repository is up to date
    test.is_repo_up_to_date(temp_git_repo)

    # Check if the output indicates that the repository is up to date
    captured = capsys.readouterr()
    assert "Local repository is up to date." in captured.out

    # Make a change in the repository
    dummy_file = temp_git_repo / "dummy.txt"
    dummy_file.write_text("Hello, world!")

    # Commit the change
    subprocess.run(['git', 'add', '.'], cwd=temp_git_repo, check=True)
    subprocess.run(['git', 'commit', '-m', 'Add dummy file'], cwd=temp_git_repo, check=True)

    # Check if the repository is not up to date after the change
    test.is_repo_up_to_date(temp_git_repo)

    # Check if the output indicates that the repository is not up to date
    captured = capsys.readouterr()
    assert "Local repository is not up to date. Pulling changes..." in captured.out

    # Simulate pulling the changes
    subprocess.run(['git', 'pull'], cwd=temp_git_repo, check=True)

    # Check if the repository is up to date after pulling
    test.is_repo_up_to_date(temp_git_repo)

    # Check if the output indicates that the changes were pulled successfully
    captured = capsys.readouterr()
    assert "Changes pulled successfully." in captured.out
